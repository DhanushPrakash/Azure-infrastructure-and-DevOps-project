<#
.SYNOPSIS
    Warns about Key Vault secrets that are expiring soon (or have no
    expiry set at all).

.DESCRIPTION
    Intended to run on a scheduled Azure DevOps pipeline (e.g. weekly) so
    secret rotation doesn't get forgotten about. Requires an authenticated
    Az context (Connect-AzAccount, or the AzurePowerShell pipeline task
    with a service connection).

.PARAMETER KeyVaultName
    Name of the Key Vault to inspect.

.PARAMETER WarningThresholdDays
    Secrets expiring within this many days will be flagged.

.EXAMPLE
    ./scripts/Test-KeyVaultSecretExpiry.ps1 -KeyVaultName kv-devopsdemo-dev-ab12c -WarningThresholdDays 30
#>

[CmdletBinding()]
param(
    [Parameter(Mandatory = $true)]
    [string]$KeyVaultName,

    [Parameter(Mandatory = $false)]
    [int]$WarningThresholdDays = 30
)

$ErrorActionPreference = "Stop"

if (-not (Get-Module -ListAvailable -Name Az.KeyVault)) {
    throw "Az.KeyVault module not found. Install with: Install-Module Az.KeyVault -Scope CurrentUser"
}

$secrets = Get-AzKeyVaultSecret -VaultName $KeyVaultName
$now = Get-Date
$flagged = @()

foreach ($secret in $secrets) {
    if (-not $secret.Expires) {
        $flagged += [PSCustomObject]@{
            Name    = $secret.Name
            Expires = "never set"
            Status  = "NO EXPIRY"
        }
        continue
    }

    $daysLeft = ($secret.Expires - $now).Days
    if ($daysLeft -le $WarningThresholdDays) {
        $flagged += [PSCustomObject]@{
            Name    = $secret.Name
            Expires = $secret.Expires
            Status  = if ($daysLeft -lt 0) { "EXPIRED" } else { "$daysLeft day(s) left" }
        }
    }
}

if ($flagged.Count -eq 0) {
    Write-Host "No secrets in '$KeyVaultName' are expiring within $WarningThresholdDays days." -ForegroundColor Green
    exit 0
}

Write-Host "The following secrets in '$KeyVaultName' need attention:" -ForegroundColor Yellow
$flagged | Format-Table -AutoSize

# Fail the pipeline step so it's visible, without blocking unrelated stages
# if the caller chooses continueOnError: true for this task.
exit 1
