<#
.SYNOPSIS
    Validates and format-checks the Terraform configuration before it is
    allowed into the apply stage of the pipeline.

.DESCRIPTION
    Runs `terraform fmt -check` and `terraform validate` against the given
    directory, and fails (non-zero exit code) if either check fails. Intended
    to be run as a pipeline task, but works fine locally too:

    ./scripts/Test-TerraformConfig.ps1 -TerraformDirectory ./terraform

.PARAMETER TerraformDirectory
    Path to the Terraform root module.
#>

[CmdletBinding()]
param(
    [Parameter(Mandatory = $false)]
    [string]$TerraformDirectory = "./terraform"
)

$ErrorActionPreference = "Stop"

if (-not (Test-Path $TerraformDirectory)) {
    throw "Terraform directory '$TerraformDirectory' not found."
}

Push-Location $TerraformDirectory
try {
    Write-Host "==> terraform fmt -check -recursive"
    terraform fmt -check -recursive
    if ($LASTEXITCODE -ne 0) {
        throw "Terraform files are not formatted correctly. Run 'terraform fmt -recursive' locally and commit the result."
    }

    Write-Host "==> terraform init -backend=false"
    terraform init -backend=false -input=false | Out-Host
    if ($LASTEXITCODE -ne 0) {
        throw "terraform init failed."
    }

    Write-Host "==> terraform validate"
    terraform validate
    if ($LASTEXITCODE -ne 0) {
        throw "terraform validate failed."
    }

    Write-Host "All Terraform checks passed." -ForegroundColor Green
}
finally {
    Pop-Location
}
