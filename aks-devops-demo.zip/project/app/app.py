import os
from pathlib import Path
from flask import Flask, jsonify

app = Flask(__name__)

# The CSI Secrets Store driver mounts Key Vault secrets as files on disk
# inside the pod, at the path configured in k8s/secretproviderclass.yaml.
SECRET_MOUNT_PATH = Path(os.environ.get("SECRET_MOUNT_PATH", "/mnt/secrets-store/app-secret"))


@app.get("/health")
def health():
    return jsonify(status="ok"), 200


@app.get("/")
def index():
    secret_loaded = SECRET_MOUNT_PATH.exists()
    return jsonify(
        message="Hello from AKS",
        pod=os.environ.get("HOSTNAME", "unknown"),
        secret_mounted=secret_loaded,
    ), 200


if __name__ == "__main__":
    app.run(host="0.0.0.0", port=8080)
