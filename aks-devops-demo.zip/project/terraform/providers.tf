terraform {
  required_version = ">= 1.5.0"

  required_providers {
    azurerm = {
      source  = "hashicorp/azurerm"
      version = "~> 3.90"
    }
    random = {
      source  = "hashicorp/random"
      version = "~> 3.6"
    }
  }

  # Remote state in Azure Storage. Values are intentionally left blank here
  # and supplied at `terraform init` time via -backend-config, either from the
  # CLI or from the pipeline (see pipelines/azure-pipelines.yml).
  #
  # terraform init \
  #   -backend-config="resource_group_name=<rg>" \
  #   -backend-config="storage_account_name=<sa>" \
  #   -backend-config="container_name=tfstate" \
  #   -backend-config="key=project.terraform.tfstate"
  backend "azurerm" {}
}

provider "azurerm" {
  features {
    key_vault {
      purge_soft_delete_on_destroy    = true
      recover_soft_deleted_key_vaults = true
    }
  }
}

provider "random" {}
