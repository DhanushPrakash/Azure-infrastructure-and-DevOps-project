variable "project_name" {
  description = "Short name used as a prefix for all resources. Lowercase, alphanumeric."
  type        = string
  default     = "devopsdemo"
}

variable "environment" {
  description = "Environment name, e.g. dev, test, prod."
  type        = string
  default     = "dev"
}

variable "location" {
  description = "Azure region for all resources."
  type        = string
  default     = "uksouth"
}

variable "aks_node_count" {
  description = "Number of nodes in the default AKS node pool."
  type        = number
  default     = 1
}

variable "aks_node_vm_size" {
  description = "VM size for AKS nodes. Kept small to control cost for a demo project."
  type        = string
  default     = "Standard_B2s"
}

variable "kubernetes_version" {
  description = "Kubernetes version for AKS. Leave null to use the current default supported by the provider/region."
  type        = string
  default     = null
}

variable "tags" {
  description = "Common tags applied to every resource."
  type        = map(string)
  default = {
    project = "devops-demo"
    managed_by = "terraform"
  }
}
