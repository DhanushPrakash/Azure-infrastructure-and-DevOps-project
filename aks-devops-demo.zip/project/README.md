# AKS DevOps Demo

A small, real, deployable project covering:

- **Terraform** — AKS, ACR, Storage Account, Key Vault, RBAC wiring
- **PowerShell** — Terraform pre-flight validation + a Key Vault secret-expiry check
- **Azure DevOps Pipelines** — multi-stage CI/CD: validate → build/push → terraform apply (with approval) → deploy
- **Kubernetes** — Deployment, Service, HPA, and Key Vault secrets mounted via the CSI Secrets Store driver (no secrets copy-pasted into K8s Secrets)

```
.
├── terraform/        # Infra as code
├── app/               # Tiny Flask app + Dockerfile
├── k8s/               # Manifests deployed by the pipeline
├── pipelines/         # azure-pipelines.yml
├── scripts/           # PowerShell helpers
└── README.md
```

## 1. One-time manual setup

### 1a. State storage (bootstrap — do this once, outside Terraform)
Terraform's own state needs somewhere to live before Terraform can manage anything else.

```bash
az group create -n rg-tfstate -l uksouth
az storage account create -n <globally-unique-sa-name> -g rg-tfstate -l uksouth --sku Standard_LRS
az storage container create -n tfstate --account-name <globally-unique-sa-name>
```

### 1b. Azure DevOps project
1. Create a new project, push this folder as the repo.
2. **Project Settings → Service connections** → new **Azure Resource Manager** connection named `azure-service-connection` (workload identity federation is preferred over a secret-based SP). Grant it Contributor on the subscription/resource group, and enough rights to create Key Vault RBAC assignments (`User Access Administrator` or `Owner` scoped narrowly, since Contributor alone can't assign roles).
3. **Pipelines → Library** → variable group named `devops-demo-vars`:
   | Variable | Value |
   |---|---|
   | `TF_BACKEND_RG` | `rg-tfstate` |
   | `TF_BACKEND_SA` | the storage account name from step 1a |
   | `TF_BACKEND_CONTAINER` | `tfstate` |
   | `ACR_NAME` | pick a name, e.g. `acrdevopsdemo` (must match what Terraform will create — see note below) |
   | `AKS_RESOURCE_GROUP` | `rg-devopsdemo-dev` (matches Terraform's naming, see `main.tf` locals) |
   | `AKS_CLUSTER_NAME` | `aks-devopsdemo-dev` |
4. **Pipelines → Environments** → create `infra-approval`, add yourself as a required approver under **Approvals and checks**. This is what makes `terraform apply` pause for a human sign-off.
5. Create a pipeline pointing at `pipelines/azure-pipelines.yml`.

> **Note on the ACR service connection used in the Build stage:** the pipeline's Docker task references an ACR-specific service connection (`$(ACR_NAME)-connection`) for simplicity. Since Terraform creates the ACR with a randomized suffix, either (a) create the ACR manually first with a fixed name and import it into Terraform state (`terraform import`), or (b) swap the Build stage to `az acr build` using the `azure-service-connection` instead of a dedicated ACR connection — simpler for a demo. The pipeline comment flags this as a decision point.

## 2. Run it
Push to `main`. The pipeline will:
1. `terraform fmt -check` + `terraform validate`
2. Build the Flask app image and push it to ACR
3. Pause for approval, then `terraform plan`/`apply` the infra
4. Substitute Terraform outputs into the K8s manifests and `kubectl apply` them

## 3. Verify
```bash
kubectl get pods -n devops-demo
kubectl get svc devops-demo-app -n devops-demo   # note the EXTERNAL-IP
curl http://<EXTERNAL-IP>/
# -> {"message": "Hello from AKS", "pod": "...", "secret_mounted": true}
```

`secret_mounted: true` confirms the full chain worked: Key Vault → AKS CSI driver → pod filesystem, with no secret ever stored in a Kubernetes Secret or a pipeline log.

## 4. Cost / cleanup
Everything here is deliberately small (`Standard_B2s` single-node AKS, `Basic` ACR). The Service in `k8s/service.yaml` is `type: LoadBalancer`, which provisions a public Azure Load Balancer — switch to `ClusterIP` + an Ingress controller if you want to avoid that cost, or just remember to tear down:
```bash
terraform -chdir=terraform destroy
az group delete -n rg-tfstate
```

## 5. Where to take this next
- Swap `az aks get-credentials` + raw `kubectl` for a Helm chart
- Add a second environment (staging/prod) via Terraform workspaces or separate tfvars + a second pipeline stage
- Add `terraform plan` as a PR-triggered stage that posts the plan as a PR comment
- Replace the manual approval with branch policies + required reviewers for a lighter-weight gate
- Add Azure Monitor / Container Insights to the AKS module
